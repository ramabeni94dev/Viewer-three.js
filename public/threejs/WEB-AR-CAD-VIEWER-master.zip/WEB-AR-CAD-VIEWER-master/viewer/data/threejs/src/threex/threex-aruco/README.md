Trying to use js-aruco as ar.js backend

- arucocontext is just a super thing layer to provide a similar level as jsartoolkit
- some good debug function in there tho, and some marker generator which help
